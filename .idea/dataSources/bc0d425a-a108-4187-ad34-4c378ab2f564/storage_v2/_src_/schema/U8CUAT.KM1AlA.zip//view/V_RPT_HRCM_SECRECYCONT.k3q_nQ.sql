create view V_RPT_HRCM_SECRECYCONT as
  select hrcm_secrecycont.pk_secrecycont, hrcm_secrecycont.pk_corp, hrcm_secrecycont.pk_psndoc, hrcm_secrecycont.vcontcode, hrcm_secrecycont.iconttype, hrcm_secrecycont.itermmonth, hrcm_secrecycont.begindate, hrcm_secrecycont.enddate, hrcm_secrecycont.signdate, hrcm_secrecycont.vsignaddr, hrcm_secrecycont.contmodel, hrcm_secrecycont.isrefer, hrcm_secrecycont.icontstate, hrcm_secrecycont.vmemo, hrcm_secrecycont.pk_conttext from hrcm_secrecycont where hrcm_secrecycont.isrefer='Y'
/

