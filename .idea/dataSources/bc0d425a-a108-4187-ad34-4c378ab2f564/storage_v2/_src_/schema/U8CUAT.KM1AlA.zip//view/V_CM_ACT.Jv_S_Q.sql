create view V_CM_ACT as
  select act.pk_act, act.pk_corp, act.pk_calbody, act.cactcode, act.cactname, act.facttypeflag, act.factobjecttypeflag, act.pk_activity, act.pk_ctcenter, act.vdef1, act.vdef2, act.vdef3, act.vdef4, act.vdef5, act.vjavapath, act.pk_genectcenter, act.pk_geneactivity, act.fnumberflag,activity.atname, ctcenter.cctcentername from cm_act act LEFT OUTER JOIN cm_ctcenter ctcenter ON act.pk_ctcenter = ctcenter.pk_ctcenter LEFT OUTER JOIN pd_at activity ON act.pk_activity = activity.pk_atid
/

