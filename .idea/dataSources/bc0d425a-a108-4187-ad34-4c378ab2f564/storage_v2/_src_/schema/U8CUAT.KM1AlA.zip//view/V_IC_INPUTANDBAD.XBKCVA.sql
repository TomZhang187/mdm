create view V_IC_INPUTANDBAD as
  SELECT h.pk_calbody ccalbodyid, b.pk_corp, h.cwarehouseid, b.cvendorid, b.cinventoryid, b.dbizdate, b.noutnum ninputnum, CAST (NULL AS numeric (20, 8)) nbadnum FROM ic_general_h h, ic_general_b b, ic_billtype bt WHERE h.cgeneralhid        = b.cgeneralhid and bt.cbilltypecode = h.cbilltypecode AND bt.cbilltypecode = '4D' AND noutnum          > 0 and b.dr             = 0 UNION ALL SELECT h.pk_calbody ccalbodyid, b.pk_corp, h.cwarehouseid, b.cvendorid, b.cinventoryid, b.dbizdate, CAST (NULL AS numeric (20, 8)) ninputnum, b.noutnum nbadnum FROM ic_general_h h, ic_general_b b, ic_billtype bt WHERE h.cgeneralhid        = b.cgeneralhid and bt.cbilltypecode = h.cbilltypecode AND bt.cbilltypecode = '4D' AND noutnum          < 0 and b.dr             = 0
/

