create view V_SF_HGX as
  select sf_pgd_b.pk_pgd_bid,count(sf_gxjh.gxh) rowsl from sf_pgd_b left outer join sf_gxjh on sf_pgd_b.scddid = sf_gxjh.pk_moid and sf_pgd_b.gxh < sf_gxjh.gxh and sf_gxjh.dr = 0 and sf_pgd_b.dr = 0 group by sf_pgd_b.pk_pgd_bid
/

