create view V_SYS_PARTYLOG as
  (select cpartyname, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_partylog.cpartyname) as cpartyname_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_partylog.cpartyname) as cpartyname_c, dpartydate, cpartyunit, cpartypsn, dpartyduedate, cexsort, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_partylog.cexsort) as cexsort_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_partylog.cexsort) as cexsort_c, cexreason, recordnum, lastflag, enddate, begindate, pk_psndoc from hi_psndoc_partylog)
/

