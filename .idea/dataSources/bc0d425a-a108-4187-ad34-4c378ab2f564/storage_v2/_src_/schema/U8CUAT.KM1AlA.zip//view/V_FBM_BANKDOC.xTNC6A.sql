create view V_FBM_BANKDOC as
  (SELECT     address, amcode, bankdoccode, bankdocname, createtime, creator, def1, def2, def3, def4, def5, dr, linkman1, linkman2, linkman3, modifier, modifytime, phone1, phone2, phone3, pk_bankdoc, pk_banktype, pk_corp, pk_fatherbank, pk_settlecenter, sealflag, shortname, ts FROM         bd_bankdoc) UNION (SELECT     address, amcode, bankdoccode, bankdocname, createtime, creator, def1, def2, def3, def4, def5, dr, linkman1, linkman2, linkman3, modifier, modifytime, phone1, phone2, phone3, pk_bankdoc, pk_banktype, pk_corp, pk_fatherbank, pk_settlecenter, sealflag, shortname, ts FROM         fbm_bankdoc)
/

