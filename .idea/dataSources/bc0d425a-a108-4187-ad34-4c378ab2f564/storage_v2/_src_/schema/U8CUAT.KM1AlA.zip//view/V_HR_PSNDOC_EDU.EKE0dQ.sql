create view V_HR_PSNDOC_EDU as
  select bd_psndoc.pk_psndoc,bd_psndoc.pk_psnbasdoc,hi_psndoc_edu.pk_psndoc_sub,hi_psndoc_edu.education,hi_psndoc_edu.degree, bd_defdoc_education.doccode as education_code,bd_defdoc_education.docname as education_name,bd_defdoc_degree.doccode as degree_code,bd_defdoc_degree.docname as degree_name,hi_psndoc_edu.recordnum,hi_psndoc_edu.lasteducation from bd_psndoc left join hi_psndoc_edu on bd_psndoc.pk_psndoc = hi_psndoc_edu.pk_psndoc left join bd_defdoc bd_defdoc_education on bd_defdoc_education.pk_defdoc = hi_psndoc_edu.education and bd_defdoc_education.pk_defdoclist = 'HI000000000000000007'left join bd_defdoc bd_defdoc_degree on bd_defdoc_degree.pk_defdoc = hi_psndoc_edu.degree and bd_defdoc_degree.pk_defdoclist = 'HI000000000000000008'
/

