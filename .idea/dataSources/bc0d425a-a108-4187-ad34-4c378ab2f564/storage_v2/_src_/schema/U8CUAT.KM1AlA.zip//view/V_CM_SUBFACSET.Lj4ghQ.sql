create view V_CM_SUBFACSET as
  select subfacset.pk_subfacset, subfacset.pk_corp, subfacset.pk_calbody, subfacset.pk_ctcenter, subfacset.pk_subfac, subfac.csubfaccode, subfac.csubfacname, subfac.ffactypeflag, subfac.bsemiflag, subfac.csourcemodulename, subfac.blastlevelflag, subfac.ffacsettypeflag, subfacset.nratio from cm_subfacset subfacset INNER JOIN cm_subfac subfac ON subfacset.pk_subfac = subfac.pk_subfac where ( subfac.dr = 0 )
/

