create view V_SYS_ORGPSN as
  select recordnum, lastflag, djoindate, bquit, dquitdate, (select orgname from om_dumorg where pk_om_dumorg=hi_psndoc_orgpsn.pk_om_dumorg) as pk_om_dumorg_n, (select orgcode from om_dumorg where pk_om_dumorg=hi_psndoc_orgpsn.pk_om_dumorg) as pk_om_dumorg_c, pk_orgrole, (select rolename from om_orgrole where pk_orgrole=hi_psndoc_orgpsn.pk_orgrole) as pk_orgrole_n, (select rolecode from om_orgrole where pk_orgrole=hi_psndoc_orgpsn.pk_orgrole) as pk_orgrole_c, villumin, pk_psndoc from hi_psndoc_orgpsn
/

