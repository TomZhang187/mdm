create view V_FI_FIX_TYPE as
  select pk_id pk_billid,billcode bill_code,save_typeid billcontracttype,savecorp corpid from  fi_fixsave where savecorp is not null union all select pk_id pk_billid,billcode bill_code,pay_typeid billcontracttype,paycorp corpid from  fi_fixsave where paycorp is not null
/

