create view V_SYS_ASS as
  (select recordnum, begindate, enddate, period, assessdate, approveflag, lastflag, bfrompe, vassesscode, vassessname, pk_assesstype, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_ass.pk_assesstype) as pk_assesstype_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_ass.pk_assesstype) as pk_assesstype_c, nassessscore, pk_perank, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_ass.pk_perank) as pk_perank_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_ass.pk_perank) as pk_perank_c, pk_psndoc from hi_psndoc_ass)
/

