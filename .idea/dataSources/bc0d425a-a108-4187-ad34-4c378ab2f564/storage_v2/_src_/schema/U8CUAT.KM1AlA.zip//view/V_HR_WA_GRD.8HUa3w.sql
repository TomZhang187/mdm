create view V_HR_WA_GRD as
  SELECT wa_prmlv.levelname + nvl(wa_seclv.levelname, '') AS levname, wa_criterion.criterionvalue, wa_criterion.pk_wa_crt, wa_criterion.pk_wa_prmlv, wa_seclv.pk_wa_seclv, wa_prmlv.pk_wa_grd,wa_grade.wagradename FROM wa_criterion left outer join wa_grade ON wa_criterion.pk_wa_grd = wa_grade.pk_wa_grd LEFT OUTER JOIN wa_prmlv ON wa_prmlv.pk_wa_prmlv = wa_criterion.pk_wa_prmlv LEFT OUTER JOIN wa_seclv ON wa_seclv.pk_wa_seclv = wa_criterion.pk_wa_seclv
/

