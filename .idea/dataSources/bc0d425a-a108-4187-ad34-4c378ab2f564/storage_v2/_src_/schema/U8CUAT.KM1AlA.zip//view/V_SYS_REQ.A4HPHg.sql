create view V_SYS_REQ as
  (select recordnum, begindate, enddate, period, pk_postrequire_h, (select postrequirename from hi_postrequire_h where pk_postrequire_h=hi_psndoc_req.pk_postrequire_h) as pk_postrequire_h_n, (select postrequirecode from hi_postrequire_h where pk_postrequire_h=hi_psndoc_req.pk_postrequire_h) as pk_postrequire_h_c, pk_postrequire_b, (select postlevelname from hi_postrequire_b where pk_postrequire_b=hi_psndoc_req.pk_postrequire_b) as pk_postrequire_b_n, (select postlevelcode from hi_postrequire_b where pk_postrequire_b=hi_psndoc_req.pk_postrequire_b) as pk_postrequire_b_c, approveflag, lastflag, villum, pk_psndoc from hi_psndoc_req)
/

