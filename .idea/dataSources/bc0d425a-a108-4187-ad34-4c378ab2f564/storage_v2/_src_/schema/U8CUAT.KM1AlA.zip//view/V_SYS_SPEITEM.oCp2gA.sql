create view V_SYS_SPEITEM as
  (select cspename, cspearea, cspesort, cspeunit, cspeunitlev, dspebegin, dspeend, cspepart, cspeben, recordnum, lastflag, pk_psndoc from hi_psndoc_speitem)
/

