create view V_SYS_TRYOUT as
  (select ctrytype, dtrybegin, dtryend, ctryresult, cchgdate, recordnum, lastflag, enddate, begindate, pk_psndoc from hi_psndoc_tryout)
/

