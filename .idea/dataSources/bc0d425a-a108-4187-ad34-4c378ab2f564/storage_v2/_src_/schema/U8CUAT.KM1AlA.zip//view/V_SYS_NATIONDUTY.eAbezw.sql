create view V_SYS_NATIONDUTY as
  (select cworkname, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_nationduty.cworkname) as cworkname_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_nationduty.cworkname) as cworkname_c, dworkdate, cworkunitname, recordnum, lastflag, pk_psndoc from hi_psndoc_nationduty)
/

