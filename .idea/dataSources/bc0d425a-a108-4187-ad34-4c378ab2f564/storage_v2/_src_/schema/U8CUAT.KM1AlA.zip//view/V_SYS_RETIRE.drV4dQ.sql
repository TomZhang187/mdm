create view V_SYS_RETIRE as
  (select recordnum, begindate, enddate, period, pension, allowance, memo, approveflag, lastflag, pk_psndoc from hi_psndoc_retire)
/

