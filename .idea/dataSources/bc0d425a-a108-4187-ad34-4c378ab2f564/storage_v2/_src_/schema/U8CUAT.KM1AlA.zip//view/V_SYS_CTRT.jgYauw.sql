create view V_SYS_CTRT as
  (select recordnum, lastflag, vcontractnum, pk_termtype, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_ctrt.pk_termtype) as pk_termtype_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_ctrt.pk_termtype) as pk_termtype_c, itermmonth, begindate, enddate, ipromonth, probenddate, iconttype, dsigndate, neconomy, vmemo, vsignaddr, isrefer, ifwrite, vprobsalary, vstartsalary, pk_unchreason, vcontractcode, nbreachmoney, pk_corp, icontstate, pk_conttext, probegindate, pk_psndoc from hi_psndoc_ctrt)
/

