create view V_PE_PERIOD as
  select pk_period,fdate,period_code,period_type,period_year,pk_corp,period, case when period ='01' or period ='02'  or period ='03'   then '1' when period ='04' or period ='05'  or period ='06'   then '2' when period ='07' or period ='08'  or period ='09'   then '3' when period ='10' or period ='11'  or period ='12'   then '4' else '0' end as quarter from pe_period
/

