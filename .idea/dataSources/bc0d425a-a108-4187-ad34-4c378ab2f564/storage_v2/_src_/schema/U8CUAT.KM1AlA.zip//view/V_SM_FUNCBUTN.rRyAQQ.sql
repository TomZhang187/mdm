create view V_SM_FUNCBUTN as
  select cFunId, fun_name, forbid_flag, fun_code, fun_level, fun_property, class_name, parent_id, group_flag,orgtypecode from sm_funcregister union select cfunid, fun_name, forbid_flag, fun_code, fun_level, fun_property, class_name, parent_id, 0 as group_flag,orgtypecode from sm_butnregister
/

