create view V_SYS_WORK as
  (select recordnum, begindate, enddate, period, workcorp, workjob, approveflag, lastflag, workdept, vworkduty, vworkachive, vworkaddr, vrelphone, vcertifier, vcertiphone, vbackgroud, vdismismatter, pk_psndoc from hi_psndoc_work)
/

