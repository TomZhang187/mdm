create view V_SYS_MAINHIS as
  (select cmainname, cmainlev, cmainpsn, cmainpsnduty, recordnum, lastflag, pk_psndoc from hi_psndoc_mainhis)
/

