create view TBM_BBFL as
  select pk_defdoc as id,null as pk_parent,doccode as lbbm,docname as lbmc,pk_corp,'bbfl' as source from bd_defdoc where pk_defdoclist='0001Z71000000000IA6M' union select pk_bclbid as id,bclbfl as pk_parent,lbbm,lbmc,pk_corp,'bb' as source from tbm_bclb where isblocked is null or isblocked='N'
/

