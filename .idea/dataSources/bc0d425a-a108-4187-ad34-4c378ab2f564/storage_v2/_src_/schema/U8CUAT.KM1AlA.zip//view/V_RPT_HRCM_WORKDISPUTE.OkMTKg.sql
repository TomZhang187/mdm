create view V_RPT_HRCM_WORKDISPUTE as
  select hrcm_workdispute.pk_workdispute, hrcm_workdispute.pk_corp, hrcm_workdispute.pk_psndoc, hrcm_workdispute.vcode, hrcm_workdispute.doccurdate, hrcm_workdispute.vreason, hrcm_workdispute.vrequest, hrcm_workdispute.composestart, hrcm_workdispute.composeend, hrcm_workdispute.iscomposesolve, hrcm_workdispute.vsolvememo, hrcm_workdispute.begindate, hrcm_workdispute.enddate, hrcm_workdispute.isintercesolve, hrcm_workdispute.vintermemo, hrcm_workdispute.lawstartdate, hrcm_workdispute.lawenddate, hrcm_workdispute.isclawsolve, hrcm_workdispute.vlawmemo, hrcm_workdispute.vaboutmemo from hrcm_workdispute
/

