create view V_SYS_ENC as
  (select recordnum, lastflag, vencourtype, vencourorg, vencourmeas, dencourdate, vencourmatter, pk_psndoc from hi_psndoc_enc)
/

