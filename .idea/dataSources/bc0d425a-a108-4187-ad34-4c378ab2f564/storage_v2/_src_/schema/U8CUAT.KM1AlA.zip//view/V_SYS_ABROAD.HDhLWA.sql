create view V_SYS_ABROAD as
  (select dabroaddate, cabroadway, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_abroad.cabroadway) as cabroadway_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_abroad.cabroadway) as cabroadway_c, cabroadarea, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_abroad.cabroadarea) as cabroadarea_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_abroad.cabroadarea) as cabroadarea_c, cabroadunit, cabroadout, cabroadgroup, cabroadoutlay, cabroadpro, dabroadprodate, cabroadnumber, dabroadreturn, cabroadex, recordnum, lastflag, enddate, begindate, pk_psndoc from hi_psndoc_abroad)
/

