create view V_SYS_PUN as
  (select recordnum, lastflag, vpunishtype, vpunishorg, vpunishmeas, dpunishdate, vpunishmatter, pk_psndoc from hi_psndoc_pun)
/

