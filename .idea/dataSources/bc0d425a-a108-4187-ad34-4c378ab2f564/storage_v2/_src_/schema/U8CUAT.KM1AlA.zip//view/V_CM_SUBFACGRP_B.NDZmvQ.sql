create view V_CM_SUBFACGRP_B as
  select subfacgrp_b.pk_group_b, subfacgrp_b.pk_group, subfacgrp_b.pk_corp, subfacgrp_b.pk_calbody, subfacgrp_b.pk_subfac, subfac.csubfaccode, subfac.csubfacname from cm_group_b subfacgrp_b INNER JOIN cm_group subfacgrp ON subfacgrp_b.pk_group = subfacgrp.pk_group INNER JOIN cm_subfac subfac ON subfacgrp_b.pk_subfac = subfac.pk_subfac where ( subfacgrp.fgrouptypeflag = 1 )
/

