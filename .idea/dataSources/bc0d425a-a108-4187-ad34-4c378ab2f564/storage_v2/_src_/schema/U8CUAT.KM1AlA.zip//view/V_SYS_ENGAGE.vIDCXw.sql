create view V_SYS_ENGAGE as
  (select cInto, cengage, cengincome, dengdate, recordnum, lastflag, enddate, begindate, pk_psndoc from hi_psndoc_engage)
/

