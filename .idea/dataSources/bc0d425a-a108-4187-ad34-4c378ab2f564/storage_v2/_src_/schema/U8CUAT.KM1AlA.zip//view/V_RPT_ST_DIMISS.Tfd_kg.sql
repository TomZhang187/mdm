create view V_RPT_ST_DIMISS as
  select hi_stapplyb_h.pk_hi_stapplyb_h, hi_stapplyb_h.pk_billtype, hi_stapplyb_h.pk_businesstype, hi_stapplyb_h.vbillno, hi_stapplyb_h.pk_sttype, hi_stapplyb_h.pk_psndoc, hi_stapplyb_h.pk_currpsncl, hi_stapplyb_h.pk_currcorp, hi_stapplyb_h.pk_currdeptdoc, hi_stapplyb_h.pk_currjob, hi_stapplyb_h.pk_dimispsncl, hi_stapplyb_h.pk_aimcorp, hi_stapplyb_h.pk_aimdeptdoc, hi_stapplyb_h.pk_aimjob, hi_stapplyb_h.deffectdate, hi_stapplyb_h.bpreform, hi_stapplyb_h.pk_proposer, hi_stapplyb_h.dappldate, hi_stapplyb_h.ibillstate, hi_stapplyb_h.pk_corp, hi_stapplyb_h.indutydate, hi_stapplyb_h.dproeffectdate from hi_stapplyb_h where hi_stapplyb_h.ibillstate = 2 and hi_stapplyb_h.pk_billtype = 'BK'
/

