create view V_SYS_JOBCHG as
  (select cjobchg, cjobmode, djobdate, dpsndate, cpsnout, recordnum, lastflag, enddate, begindate, pk_psndoc from hi_psndoc_jobchg)
/

