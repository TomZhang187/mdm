create view V_HR_PSNDOC_MULTI_JOB as
  select pk_psndoc,pk_corp,pk_psncl,pk_deptdoc,pk_postdoc,pk_jobserial,pk_jobrank,pk_om_duty,pk_detytype,jobtype, iscalovertime, tbm_prop, timecardid ,'正式' as jobtypename from hi_psndoc_deptchg where bendflag = 'N' and lastflag = 'Y'
/

