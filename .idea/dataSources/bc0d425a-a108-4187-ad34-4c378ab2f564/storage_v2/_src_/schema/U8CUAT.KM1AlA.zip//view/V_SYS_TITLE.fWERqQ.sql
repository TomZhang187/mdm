create view V_SYS_TITLE as
  (select recordnum, lastflag, pk_techposttitle, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_title.pk_techposttitle) as pk_techposttitle_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_title.pk_techposttitle) as pk_techposttitle_c, begindate, enddate, vassorg, vstrongsuit, vcertifcode, vachive, vsumm, pk_psndoc from hi_psndoc_title)
/

