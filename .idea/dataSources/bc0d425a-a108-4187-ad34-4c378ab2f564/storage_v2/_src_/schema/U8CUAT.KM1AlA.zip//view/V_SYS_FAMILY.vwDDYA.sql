create view V_SYS_FAMILY as
  (select recordnum, begindate, enddate, period, mem_name, mem_relation, mem_birthday, mem_corp, mem_job, approveflag, lastflag, vprofession, vrelaaddr, vrelaphone, pk_psndoc from hi_psndoc_family)
/

