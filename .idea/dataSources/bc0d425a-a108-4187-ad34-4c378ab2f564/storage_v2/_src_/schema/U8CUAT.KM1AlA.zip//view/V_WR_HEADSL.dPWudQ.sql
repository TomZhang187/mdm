create view V_WR_HEADSL as
  select pk_wrid,sum(nvl(rksl,0)) as rksl,sum(nvl(ljyrsl,0)) as ljyrsl from mm_wr_b where dr = 0 group by pk_wrid
/

