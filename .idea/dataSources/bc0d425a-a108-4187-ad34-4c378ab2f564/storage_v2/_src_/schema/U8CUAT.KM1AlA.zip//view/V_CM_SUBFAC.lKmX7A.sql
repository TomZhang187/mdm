create view V_CM_SUBFAC as
  SELECT subfac.pk_subfac, subfac.pk_corp, subfac.csubfacname, subfac.csubfaccode, fac.csubfacname AS facname, subfac.ffactypeflag, subfac.ffacsettypeflag, subfac.blastlevelflag, subfac.bsemiflag, subfac.csourcemodulename, subfac.isassflag, subfac.parentsubfac, subfac.pk_measdoc, bd_measdoc.measname, subfac.subfaclevel,subfac.isdetail FROM cm_subfac subfac LEFT OUTER JOIN bd_measdoc ON subfac.pk_measdoc = bd_measdoc.pk_measdoc LEFT OUTER JOIN cm_subfac fac ON subfac.parentsubfac = fac.pk_subfac WHERE (subfac.dr = 0)
/

