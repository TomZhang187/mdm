create view V_RPT_HRCM_POSTCONT as
  select hrcm_postcont.pk_postcont, hrcm_postcont.pk_corp, hrcm_postcont.pk_psndoc, hrcm_postcont.vcontcode, hrcm_postcont.iconttype, hrcm_postcont.itermmonth, hrcm_postcont.begindate, hrcm_postcont.enddate, hrcm_postcont.pk_company, hrcm_postcont.pk_post, hrcm_postcont.iprobmonth, hrcm_postcont.probenddate, hrcm_postcont.vprobsalary, hrcm_postcont.vstartsalary, hrcm_postcont.contmodel, hrcm_postcont.isrefer, hrcm_postcont.icontstate, hrcm_postcont.vmemo, hrcm_postcont.designdate, hrcm_postcont.vsignaddr, hrcm_postcont.pk_conttext from hrcm_postcont where hrcm_postcont.isrefer='Y'
/

