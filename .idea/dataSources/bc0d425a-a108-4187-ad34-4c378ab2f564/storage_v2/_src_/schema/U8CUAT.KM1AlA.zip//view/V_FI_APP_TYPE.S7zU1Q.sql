create view V_FI_APP_TYPE as
  select pk_id pk_billid,code bill_code,debtor_contype billcontracttype,debtor_corp corpid from  fi_cont_app where debtor_corp is not null union all select pk_id pk_billid,code bill_code,creditor_contype billcontracttype,creditor_corp corpid from  fi_cont_app where creditor_corp is not null union all select pk_id pk_billid,code bill_code,guarantor_contype billcontracttype,guarantor_corp corpid from  fi_cont_app where guarantor_corp is not null
/

