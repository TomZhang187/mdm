create view V_JC_JOB as
  select bd_jobmngfil.pk_jobmngfil, bd_jobbasfil.jobcode, bd_jobbasfil.jobname, bd_jobmngfil.pk_corp, bd_jobbasfil.pk_jobtype from bd_jobbasfil, bd_jobmngfil where bd_jobmngfil.pk_jobbasfil = bd_jobbasfil.pk_jobbasfil
/

