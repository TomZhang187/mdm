create view V_SYS_LAGABILITY as
  (select clagsort, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_lagability.clagsort) as clagsort_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_lagability.clagsort) as clagsort_c, clagskill, (select docname from bd_defdoc where pk_defdoc=hi_psndoc_lagability.clagskill) as clagskill_n, (select doccode from bd_defdoc where pk_defdoc=hi_psndoc_lagability.clagskill) as clagskill_c, claglev, recordnum, lastflag, pk_psndoc from hi_psndoc_lagability)
/

